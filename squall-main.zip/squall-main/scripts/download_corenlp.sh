#!/bin/bash

wget http://nlp.stanford.edu/software/stanford-corenlp-full-2018-10-05.zip .
unzip stanford-corenlp-full-2018-10-05.zip
rm stanford-corenlp-full-2018-10-05.zip
mv stanford-corenlp-full-2018-10-05 ../
